///////////////////////////////////////////////////////////////////////////////
// render.cpp
// ========
// Functions for rendering objects in OpenGL
//
//  AUTHOR: 
///////////////////////////////////////////////////////////////////////////////


#include "render.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h" // Image class

#include <iostream>
using namespace std;

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library


//	Container for all of the textures
std::map<std::string, GLuint> textureMap;
GLuint gTextureId;


// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
	for (int j = 0; j < height / 2; ++j)
	{
		int index1 = j * width * channels;
		int index2 = (height - 1 - j) * width * channels;

		for (int i = width * channels; i > 0; --i)
		{
			unsigned char tmp = image[index1];
			image[index1] = image[index2];
			image[index2] = tmp;
			++index1;
			++index2;
		}
	}
}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
	int width, height, channels;
	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
	if (image)
	{
		flipImageVertically(image, width, height, channels);

		glGenTextures(1, &textureId);
		glBindTexture(GL_TEXTURE_2D, textureId);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (channels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (channels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			cout << "Not implemented to handle image with " << channels << " channels" << endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		return true;
	}

	// Error loading the image
	return false;
}


void UDestroyTexture(GLuint textureId)
{
	glGenTextures(1, &textureId);
}

void bindTextures() {
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, 1);

	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, 2);

	glActiveTexture(GL_TEXTURE2);
	glBindTexture(GL_TEXTURE_2D, 3);

	glActiveTexture(GL_TEXTURE3);
	glBindTexture(GL_TEXTURE_2D, 4);

	glActiveTexture(GL_TEXTURE4);
	glBindTexture(GL_TEXTURE_2D, 5);

	glActiveTexture(GL_TEXTURE5);
	glBindTexture(GL_TEXTURE_2D, 6);

	glActiveTexture(GL_TEXTURE6);
	glBindTexture(GL_TEXTURE_2D, 7);

	glActiveTexture(GL_TEXTURE7);
	glBindTexture(GL_TEXTURE_2D, 8);

	glActiveTexture(GL_TEXTURE8);
	glBindTexture(GL_TEXTURE_2D, 9);

	glActiveTexture(GL_TEXTURE9);
	glBindTexture(GL_TEXTURE_2D, 10);
}

bool loadTextures(GLuint gProgramId) {
	GLuint gTable = 1;
	GLuint gNotebook = 2;
	GLuint gNotebookBinding = 3;
	GLuint gCupDesign = 4;
	GLuint gLightbulb = 5;
	GLuint gLampHead = 6;
	GLuint gLampRim = 7;
	GLuint gTabletScreen = 8;
	GLuint gTabletMaterial = 9;
	GLuint gCupLid = 10;

	cout << "Loading textures..." << endl;

	if (!UCreateTexture("../FinalProject/resources/textures/wood_table.jpg", gTable)) {
		return false;
	}

	if (!UCreateTexture("../FinalProject/resources/textures/notebook.jpg", gNotebook)) {
		return false;
	}

	if (!UCreateTexture("../FinalProject/resources/textures/notebook-binding.png", gNotebookBinding)) {
		return false;	
	}

	if (!UCreateTexture("../FinalProject/resources/textures/cup-design.png", gCupDesign)) {
		return false;
	}

	if (!UCreateTexture("../FinalProject/resources/textures/glass.png", gLightbulb)) {
		return false;
	}

	if (!UCreateTexture("../FinalProject/resources/textures/metal-2.png", gLampHead)) {
		return false;
	}

	if (!UCreateTexture("../FinalProject/resources/textures/metal-3.png", gLampRim)) {
		return false;
	}

	if (!UCreateTexture("../FinalProject/resources/textures/screen.png", gTabletScreen)) {
		return false;
	}

	if (!UCreateTexture("../FinalProject/resources/textures/brushed-metal.jpg", gTabletMaterial)) {
		return false;
	}

	if (!UCreateTexture("../FinalProject/resources/textures/cup_lid.jpg", gCupLid)) {
		return false;
	}

	cout << "Textures loaded successfully." << endl;
	return true;
}


void URenderPlane(Meshes meshes, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc, GLint textureId) {
	glm::mat4 scale;
	glm::mat4 rotation;
	glm::mat4 translation;
	glm::mat4 model;

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gPlaneMesh.vao);

	// 1. Scales the object
	scale = glm::scale(glm::vec3(6.0f, 1.0f, 4.0f));

	// 2. Rotate the object
	rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));

	// 3. Position the object
	translation = glm::translate(glm::vec3(0.0f, 0.0f, 2.0f));

	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));	

	// Bind textures on corresponding texture units
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);

	// Draws the triangles
	glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
}

//	Renders the individual meshes of the lamp to form an entire lamp object
void URenderLamp(Meshes meshes, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc, glm::vec3 translate, glm::mat4 rotation) {
	LampMeshProperties lampMeshProperties;

	//	Define the properties for the lamp head, then render it
	lampMeshProperties.lampHead = MeshProperties(glm::vec3(1.0f, 1.0f, 1.0f), glm::rotate(glm::radians(80.0f), glm::vec3(1.0, 1.0f, 1.0f)) * glm::rotate(glm::radians(-80.0f), glm::vec3(1.0, 0.0f, 0.0f)) * rotation,
		translate + glm::vec3(-1.02f, 3.4f, 1.0f), 0.0f, 1.0f, 0.0f, 1.0f);
	URenderLampHead(meshes, lampMeshProperties.lampHead, gProgramId, modelLoc, objectColorLoc);

	//	Define the properties for the lamp rim, then render it
	lampMeshProperties.lampHeadRim = MeshProperties(glm::vec3(1.0f, 1.0f, 1.0f), glm::rotate(glm::radians(245.0f), glm::vec3(0.0, 0.0f, 1.0f)) * glm::rotate(glm::radians(-74.0f), glm::vec3(1.0, 0.0f, 0.0f)) * rotation,
		translate + glm::vec3(-1.0f, 3.4f, 1.0f), 0.0f, 0.6f, 0.0f, 1.0f);
	URenderLampHeadRim(meshes, lampMeshProperties.lampHeadRim, gProgramId, modelLoc, objectColorLoc);

	//	Define the properties for the lamp lightbulb, then render it
	lampMeshProperties.lampLightbulb = MeshProperties(glm::vec3(0.5f, 0.5f, 0.5f), glm::rotate(glm::radians(240.0f), glm::vec3(0.0, 0.0f, 1.0f)) * glm::rotate(glm::radians(-60.0f), glm::vec3(1.0, 0.0f, 0.0f)) * rotation,
		translate + glm::vec3(-1.5f, 3.6f, 0.8f), 1.0f, 1.0f, 0.0f, 1.0f);
	URenderLampLightbulb(meshes, lampMeshProperties.lampLightbulb, gProgramId, modelLoc, objectColorLoc);

	//	Define the properties for the lamp head to switch , then render ita
	lampMeshProperties.lampHeadToSwitch = MeshProperties(glm::vec3(0.4f, 0.9f, 0.5f), glm::rotate(glm::radians(80.0f), glm::vec3(1.0, 1.0f, 1.0f)) * glm::rotate(glm::radians(-80.0f), glm::vec3(1.0, 0.0f, 0.0f)) * rotation,
		translate + glm::vec3(-1.9f, 3.8f, 0.74f), 0.0f, 0.7f, 0.7f, 1.0f);
	URenderLampHeadToSwitch(meshes, lampMeshProperties.lampHeadToSwitch, gProgramId, modelLoc, objectColorLoc);

	//	Define the properties for the lamp's power switch , then render it
	lampMeshProperties.lampPowerSwitch = MeshProperties(glm::vec3(0.2f, 0.2f, 0.2f), glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f)) * rotation,
		translate + glm::vec3(-2.7f, 4.1f, 0.43f), 1.0f, 0.0f, 1.0f, 1.0f);
	URenderLampPowerSwitch(meshes, lampMeshProperties.lampPowerSwitch, gProgramId, modelLoc, objectColorLoc);	

	//	Define the properties for the lamp's stem, then render it
	lampMeshProperties.lampStem = MeshProperties(glm::vec3(2.2f, 2.0f, 2.0f), (glm::rotate(glm::radians(90.0f), glm::vec3(0.0, 0.0f, 1.0f)) * glm::rotate(glm::radians(-25.0f), glm::vec3(1.0, 0.0f, 0.0f)) * rotation),
		translate + glm::vec3(-2.1f, 1.5f, 0.65f), 0.0f, 1.0f, 1.0f, 1.0f);
	URenderLampStem(meshes, lampMeshProperties.lampStem, gProgramId, modelLoc, objectColorLoc);

	//	Define the properties for the lamp's clip
	lampMeshProperties.lampClip = MeshProperties(glm::vec3(1.1f, 1.0f, 1.0f), glm::rotate(glm::radians(90.0f), glm::vec3(0.0, 0.0f, 1.0f)) * glm::rotate(glm::radians(65.0f), glm::vec3(1.0, 0.0f, 0.0f)) * rotation,
		translate + glm::vec3(-1.8f, -0.9, 0.8f), 0.0f, 0.7f, 0.7f, 1.0f);
	URenderLampClip(meshes, lampMeshProperties.lampClip, gProgramId, modelLoc, objectColorLoc);
}

//	Function that appiles the scale, rotation, and translation vectors to any mesh via its meshProps
void URender(Meshes::GLMesh mesh, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	glm::mat4 scale;
	glm::mat4 rotation;
	glm::mat4 translation;
	glm::mat4 model;

	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(mesh.vao);

	// 1. Scales the object
	scale = glm::scale(meshProps.scale);

	// 2. Rotate the object
	rotation = meshProps.rotation;

	// 3. Position the object
	translation = glm::translate(meshProps.translation);

	// Model matrix: transformations are applied right-to-left order
	model = translation * rotation * scale;

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glProgramUniform4f(gProgramId, objectColorLoc, meshProps.r, meshProps.g, meshProps.b, meshProps.a);
}

void URenderLampHead(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gTaperedCylinderMesh.vao);

	URender(meshes.gTaperedCylinderMesh, meshProps, gProgramId, modelLoc, objectColorLoc);

	// bind textures on corresponding texture units
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 5);

	// Draws the triangles
	//glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
}

void URenderLampHeadRim(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gTorusMesh.vao);

	URender(meshes.gTorusMesh, meshProps, gProgramId, modelLoc, objectColorLoc);

	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 6);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, meshes.gTorusMesh.nVertices);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
}

void URenderLampLightbulb(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gSphereMesh.vao);

	URender(meshes.gSphereMesh, meshProps, gProgramId, modelLoc, objectColorLoc);

	// Bind textures on corresponding texture units
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 4);

	// Draws the triangles
	glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
}

void URenderLampHeadToSwitch(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gCylinderMesh.vao);

	URender(meshes.gCylinderMesh, meshProps, gProgramId, modelLoc, objectColorLoc);

	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 6);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
}

void URenderLampPowerSwitch(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gSphereMesh.vao);

	URender(meshes.gSphereMesh, meshProps, gProgramId, modelLoc, objectColorLoc);

	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 4);

	// Draws the triangles
	glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
}

void URenderLampStem(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gTorusMesh.vao);

	URender(meshes.gTorusMesh, meshProps, gProgramId, modelLoc, objectColorLoc);

	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 6);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, meshes.gTorusMesh.nVertices  / 2);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
}

void URenderLampClip(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gPrismMesh.vao);

	URender(meshes.gPrismMesh, meshProps, gProgramId, modelLoc, objectColorLoc);

	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 5);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLE_STRIP, 0, meshes.gPrismMesh.nVertices);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
}


//	Function to render the entire cup
void URenderCup(Meshes meshes, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc, glm::vec3 translate, glm::mat4 rotation) {
	CupMeshProperties cupMeshProperties;

	//	Define the properties for the lamp head, then render it
	cupMeshProperties.cupBody = MeshProperties(glm::vec3(0.5f, 2.5f, 0.5f), glm::rotate(glm::radians(0.0f), glm::vec3(1.0, 1.0f, 1.0f)) * glm::rotate(glm::radians(0.0f), glm::vec3(1.0, 0.0f, 0.0f)) * rotation,
		translate + glm::vec3(0.0f, 0.05, 0.0f), 0.0f, 1.0f, 0.0f, 1.0f);
	URenderCupBody(meshes, cupMeshProperties.cupBody, gProgramId, modelLoc, objectColorLoc);

	cupMeshProperties.cupLid = MeshProperties(glm::vec3(0.52f, 0.2f, 0.52f), glm::rotate(glm::radians(0.0f), glm::vec3(1.0, 1.0f, 1.0f)) * glm::rotate(glm::radians(0.0f), glm::vec3(1.0, 0.0f, 0.0f)) * rotation,
		translate + glm::vec3(0.0f, 2.5f, 0.0f), 0.0f, 1.0f, 0.0f, 1.0f);
	URenderCupLid(meshes, cupMeshProperties.cupLid, gProgramId, modelLoc, objectColorLoc);
}

//	Functions to render the individual components of a cup
void URenderCupBody(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gCylinderMesh.vao);

	URender(meshes.gCylinderMesh, meshProps, gProgramId, modelLoc, objectColorLoc);

	// Bind textures on corresponding texture units
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 3);

	GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
	glUniform2fv(UVScaleLoc, 1, glm::value_ptr(glm::vec2(3.0f, 1.0f)));

	//	Lighting variables
	GLint viewPosLoc;
	GLint ambStrLoc;
	GLint ambColLoc;
	GLint light1ColLoc;
	GLint light1PosLoc;
	GLint light2ColLoc;
	GLint light2PosLoc;
	GLint objColLoc;
	GLint specInt1Loc;
	GLint highlghtSz1Loc;
	GLint specInt2Loc;
	GLint highlghtSz2Loc;
	GLint uHasTextureLoc;
	bool ubHasTextureVal;

	viewPosLoc = glGetUniformLocation(gProgramId, "viewPosition");
	ambStrLoc = glGetUniformLocation(gProgramId, "ambientStrength");
	ambColLoc = glGetUniformLocation(gProgramId, "ambientColor");
	light1ColLoc = glGetUniformLocation(gProgramId, "light1Color");
	light1PosLoc = glGetUniformLocation(gProgramId, "light1Position");
	light2ColLoc = glGetUniformLocation(gProgramId, "light2Color");
	light2PosLoc = glGetUniformLocation(gProgramId, "light2Position");
	objColLoc = glGetUniformLocation(gProgramId, "objectColor");
	specInt1Loc = glGetUniformLocation(gProgramId, "specularIntensity1");
	highlghtSz1Loc = glGetUniformLocation(gProgramId, "highlightSize1");
	specInt2Loc = glGetUniformLocation(gProgramId, "specularIntensity2");
	highlghtSz2Loc = glGetUniformLocation(gProgramId, "highlightSize2");
	uHasTextureLoc = glGetUniformLocation(gProgramId, "ubHasTexture");

	//	Light from the monitor
	glUniform3f(light1ColLoc, 1.0f, 0.85f, 0.5f);
	glUniform3f(light1PosLoc, -18.0f, -214.0f, 144.0f);

	//set specular intensity
	glUniform1f(specInt1Loc, 1.0f);
	glUniform1f(specInt2Loc, 1.6f);

	//set specular highlight size
	glUniform1f(highlghtSz1Loc, 2.0f);
	glUniform1f(highlghtSz2Loc, 12.0f);

	ubHasTextureVal = true;
	glUniform1i(uHasTextureLoc, ubHasTextureVal);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
	//glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	glUniform2fv(UVScaleLoc, 1, glm::value_ptr(glm::vec2(1.0f, 1.0f)));
}

void URenderCupLid(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gCylinderMesh.vao);

	URender(meshes.gCylinderMesh, meshProps, gProgramId, modelLoc, objectColorLoc);

	// Bind textures on corresponding texture units
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 9);

	GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
	glUniform2fv(UVScaleLoc, 1, glm::value_ptr(glm::vec2(1.0f, 1.0f)));

	// Draws the triangles
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
	glUniform2fv(UVScaleLoc, 1, glm::value_ptr(glm::vec2(1.0f, 1.0f)));
}


//	Function to render the entire notebook
void URenderNotebook(Meshes meshes, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc, glm::vec3 translate, glm::mat4 rotation) {
	NotebookMeshProperties notebookMeshProperties;

	//	Define the properties for the lamp head, then render it
	notebookMeshProperties.notebookBody = MeshProperties(glm::vec3(2.5f, 3.17f, 0.3f), glm::rotate(glm::radians(90.0f), glm::vec3(1.0, 0.0f, 0.0f)) * glm::rotate(glm::radians(135.0f), glm::vec3(0.0, 0.0f, 1.0f)) * rotation,
		translate + glm::vec3(0.0f, 0.2f, 0.0f), 0.0f, 1.0f, 0.0f, 1.0f);
	URenderNotebookBody(meshes, notebookMeshProperties.notebookBody, gProgramId, modelLoc, objectColorLoc);
}

//	Functions to render the individual components of a notebook
void URenderNotebookBody(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gBoxMesh.vao);

	URender(meshes.gBoxMesh, meshProps, gProgramId, modelLoc, objectColorLoc);

	//	Draw the main body of the notebook
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 1);

	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices / 5, GL_UNSIGNED_INT, (void*)0);
	//glBindTexture(GL_TEXTURE_2D, 0);

	//	Draw the binding of the notebook
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 2);

	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
}

//	Function to render the entire notebook
void URenderTablet(Meshes meshes, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc, glm::vec3 translate, glm::mat4 rotation) {
	TabletMeshProperties tabletMeshProperties;

	//	Define the properties for the lamp head, then render it
	tabletMeshProperties.tabletBody = MeshProperties(glm::vec3(2.5f, 1.7f, 0.1f), 
		glm::rotate(glm::radians(-25.0f), glm::vec3(1.0, 0.0f, 0.0f)) 
		* glm::rotate(glm::radians(-30.0f), glm::vec3(0.0, 1.0f, 0.0f))
		* glm::rotate(glm::radians(-13.0f), glm::vec3(0.0, 0.0f, 1.0f)),
		translate + glm::vec3(0.0f, 0.82f, 0.0f), 0.0f, 1.0f, 0.0f, 1.0f);
	URenderTabletBody(meshes, tabletMeshProperties.tabletBody, gProgramId, modelLoc, objectColorLoc);

	tabletMeshProperties.tabletBodyBack = MeshProperties(glm::vec3(2.56, 1.8, 0.11f),
		glm::rotate(glm::radians(-25.0f), glm::vec3(1.0, 0.0f, 0.0f))
		* glm::rotate(glm::radians(-30.0f), glm::vec3(0.0, 1.0f, 0.0f))
		* glm::rotate(glm::radians(-13.0f), glm::vec3(0.0, 0.0f, 1.0f)),
		translate + glm::vec3(0.0f, 0.82f, -0.01f), 0.0f, 1.0f, 0.0f, 1.0f);
	URenderTabletBodyBack(meshes, tabletMeshProperties.tabletBodyBack, gProgramId, modelLoc, objectColorLoc);

	tabletMeshProperties.tabletStand = MeshProperties(glm::vec3(1.2f, 1.7f, 0.6f),
		glm::rotate(glm::radians(-45.0f), glm::vec3(1.0, 0.0f, 0.0f))
		* glm::rotate(glm::radians(-24.0f), glm::vec3(0.0, 1.0f, 0.0f))
		* glm::rotate(glm::radians(-24.0f), glm::vec3(0.0, 0.0f, 1.0f)),
		translate + glm::vec3(0.3f, 0.4f, -0.4f), 0.0f, 1.0f, 0.0f, 1.0f);
	URenderTabletStand(meshes, tabletMeshProperties.tabletStand, gProgramId, modelLoc, objectColorLoc);
}

//	Functions to render the individual components of a cup
void URenderTabletBody(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gBoxMesh.vao);

	URender(meshes.gBoxMesh, meshProps, gProgramId, modelLoc, objectColorLoc);

	//	Lighting variables
	GLint viewPosLoc;
	GLint ambStrLoc;
	GLint ambColLoc;
	GLint light1ColLoc;
	GLint light1PosLoc;
	GLint light2ColLoc;
	GLint light2PosLoc;
	GLint objColLoc;
	GLint specInt1Loc;
	GLint highlghtSz1Loc;
	GLint specInt2Loc;
	GLint highlghtSz2Loc;
	GLint uHasTextureLoc;
	bool ubHasTextureVal;

	viewPosLoc = glGetUniformLocation(gProgramId, "viewPosition");
	ambStrLoc = glGetUniformLocation(gProgramId, "ambientStrength");
	ambColLoc = glGetUniformLocation(gProgramId, "ambientColor");
	light1ColLoc = glGetUniformLocation(gProgramId, "light1Color");
	light1PosLoc = glGetUniformLocation(gProgramId, "light1Position");
	light2ColLoc = glGetUniformLocation(gProgramId, "light2Color");
	light2PosLoc = glGetUniformLocation(gProgramId, "light2Position");
	objColLoc = glGetUniformLocation(gProgramId, "objectColor");
	specInt1Loc = glGetUniformLocation(gProgramId, "specularIntensity1");
	highlghtSz1Loc = glGetUniformLocation(gProgramId, "highlightSize1");
	specInt2Loc = glGetUniformLocation(gProgramId, "specularIntensity2");
	highlghtSz2Loc = glGetUniformLocation(gProgramId, "highlightSize2");
	uHasTextureLoc = glGetUniformLocation(gProgramId, "ubHasTexture");

	//	Light from the monitor
	glUniform3f(light1ColLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(light1PosLoc, -18.0f, -114.0f, 144.0f);

	//set specular intensity
	glUniform1f(specInt1Loc, 1.0f);
	glUniform1f(specInt2Loc, 1.6f);

	//set specular highlight size
	glUniform1f(highlghtSz1Loc, 2.0f);
	glUniform1f(highlghtSz2Loc, 12.0f);

	ubHasTextureVal = true;
	glUniform1i(uHasTextureLoc, ubHasTextureVal);

	// bind textures on corresponding texture units
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 7);

	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
}

void URenderTabletBodyBack(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gBoxMesh.vao);

	URender(meshes.gBoxMesh, meshProps, gProgramId, modelLoc, objectColorLoc);

	// bind textures on corresponding texture units
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 8);

	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
}

void URenderTabletStand(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc) {
	glBindVertexArray(meshes.gPlaneMesh.vao);

	URender(meshes.gPlaneMesh, meshProps, gProgramId, modelLoc, objectColorLoc);

	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 8);

	// Draws the triangles
	glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
}