///////////////////////////////////////////////////////////////////////////////
// render.h
// ========
// Functions for rendering objects in OpenGL
//
//  AUTHOR: 
///////////////////////////////////////////////////////////////////////////////

#ifndef RENDER_H
#define RENDER_H

#include <GL/glew.h>        // GLEW library
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <map>
#include <string>
#include "meshes.h"

using std::map;
using std::string;

// Texture id

//	A struct to hold the common properties of a mesh
struct MeshProperties {

	MeshProperties() {
		this->scale = glm::vec3(0, 0, 0);
		this->rotation = glm::rotate(0.0f, glm::vec3(0, 0, 0));
		this->translation = glm::vec3(0, 0, 0);
		this->r = this->g = this->b = this->a = 0.0;
	}

	MeshProperties(glm::vec3 scale, glm::mat4 rotation, glm::vec3 translation, float r, float g, float b, float a) {
		this->scale = scale;
		this->rotation = rotation;
		this->translation = translation;

		this->r = r;
		this->g = g;
		this->b = b;
		this->a = a;
	}

	MeshProperties(glm::vec3 scale, glm::mat4 rotation, glm::vec3 translation, GLuint textureId) {
		this->scale = scale;
		this->rotation = rotation;
		this->translation = translation;
	}

	glm::vec3 scale;
	float rotationAngle;
	glm::mat4 rotation;
	glm::vec3 translation;
	float r, b, g, a;
};

//	A struct to hold all of the individual properties for the meshes that make up a lamp object
struct LampMeshProperties {
	LampMeshProperties() {

	}

	MeshProperties lampHead, lampHeadRim, lampLightbulb, lampHeadToSwitch, lampPowerSwitch, lampStem, lampClip;
};

struct CupMeshProperties {
	CupMeshProperties() {

	}

	MeshProperties cupBody;
	MeshProperties cupLid;
};

struct NotebookMeshProperties {
	NotebookMeshProperties() {

	}

	MeshProperties notebookBody;
};

struct TabletMeshProperties {
	TabletMeshProperties() {

	}

	MeshProperties tabletBody;
	MeshProperties tabletBodyBack;
	MeshProperties tabletStand;
};

bool UCreateTexture(const char* filename, GLuint& textureId);
bool loadTextures(GLuint gProgramId);
void bindTextures();

void URenderPlane(Meshes, GLuint, GLint, GLint, GLint);
void URender(Meshes::GLMesh mesh, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);

//	Function to render the entire lamp
void URenderLamp(Meshes meshes, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc, glm::vec3 translate, glm::mat4 rotation);

//	Functions to render the individual components of a lamp
void URenderLampHead(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);
void URenderLampHeadRim(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);
void URenderLampLightbulb(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);
void URenderLampHeadToSwitch(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);
void URenderLampPowerSwitch(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);
void URenderLampStem(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);
void URenderLampClip(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);

//	Function to render the entire cup
void URenderCup(Meshes meshes, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc, glm::vec3 translate, glm::mat4 rotation);

//	Functions to render the individual components of a cup
void URenderCupBody(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);
void URenderCupLid(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);

//	Function to render the entire notebook
void URenderNotebook(Meshes meshes, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc, glm::vec3 translate, glm::mat4 rotation);

//	Functions to render the individual components of a notebook
void URenderNotebookBody(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);

//	Function to render the entire notebook
void URenderTablet(Meshes meshes, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc, glm::vec3 translate, glm::mat4 rotation);

//	Functions to render the individual components of a tablet
void URenderTabletBody(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);
void URenderTabletBodyBack(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);
void URenderTabletStand(Meshes meshes, MeshProperties meshProps, GLuint gProgramId, GLint modelLoc, GLint objectColorLoc);

#endif